//
//  StefFrame.h
//  StefFrame
//
//  Created by Andy Stef on 14.09.2020.
//  Copyright © 2020 Andy Stef. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StefFrame.
FOUNDATION_EXPORT double StefFrameVersionNumber;

//! Project version string for StefFrame.
FOUNDATION_EXPORT const unsigned char StefFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StefFrame/PublicHeader.h>


